import { issueToken } from '../middleware/auth.js';
const role = process.argv[2] || 'viewer';
const email = process.argv[3] || 'viewer@example.com';
const token = issueToken({ role, email });
console.log(JSON.stringify({ role, email, token }, null, 2));
