import express from 'express';
import Joi from 'joi';
import { Animal } from '../models/animal.js';
import { adoptabilityScore } from '../services/scoring.js';
import { LRUCache } from '../services/cache.js';
import { authMiddleware } from '../middleware/auth.js';
import { validate } from '../middleware/validate.js';

const router = express.Router();
const cache = new LRUCache(100);

const createSchema = Joi.object({
  name: Joi.string().trim().min(1).required(),
  species: Joi.string().valid('dog','cat').default('dog'),
  breed: Joi.string().trim().allow(''),
  age: Joi.number().min(0).default(0),
  temperament: Joi.string().valid('calm','active','anxious','aggressive','balanced').default('balanced'),
  notes: Joi.string().allow('').default(''),
  healthFlags: Joi.array().items(Joi.string()).default([]),
  trainingHistory: Joi.number().min(0).default(0),
  location: Joi.object({
    type: Joi.string().valid('Point').default('Point'),
    coordinates: Joi.array().ordered(Joi.number(), Joi.number()).length(2).default([0,0])
  }).default({ type:'Point', coordinates:[0,0] })
});

router.get('/', async (req, res) => {
  try {
    const { breed, ageMin, ageMax, q, nearLat, nearLon, nearKm } = req.query;
    const key = JSON.stringify({ breed, ageMin, ageMax, q, nearLat, nearLon, nearKm });
    const cached = cache.get(key);
    if (cached) return res.json({ cached: true, data: cached });

    const filter = {};
    if (breed) filter.breed = breed;
    if (ageMin || ageMax) filter.age = {};
    if (ageMin) filter.age.$gte = Number(ageMin);
    if (ageMax) filter.age.$lte = Number(ageMax);
    if (q) filter.$text = { $search: q };

    let query = Animal.find(filter).lean();
    if (nearLat && nearLon && nearKm) {
      query = query.where('location').near({
        center: { type: 'Point', coordinates: [Number(nearLon), Number(nearLat)] },
        maxDistance: Number(nearKm) * 1000
      });
    }

    const animals = await query.limit(200);
    const withScores = animals.map(a => ({ ...a, score: adoptabilityScore(a) }));

    cache.set(key, withScores);
    res.json({ cached: false, data: withScores });
  } catch (e) {
    console.error(e);
    res.status(500).json({ error: 'Server error' });
  }
});

router.post('/', authMiddleware(['admin']), validate(createSchema), async (req, res) => {
  try {
    const doc = await Animal.create(req.body);
    cache.clear();
    res.status(201).json(doc);
  } catch (e) {
    console.error(e);
    res.status(400).json({ error: 'Create failed' });
  }
});

router.put('/:id', authMiddleware(['admin']), validate(createSchema), async (req, res) => {
  try {
    const updated = await Animal.findByIdAndUpdate(req.params.id, req.body, { new: true, runValidators: true });
    if (!updated) return res.status(404).json({ error: 'Not found' });
    cache.clear();
    res.json(updated);
  } catch (e) {
    console.error(e);
    res.status(400).json({ error: 'Update failed' });
  }
});

router.delete('/:id', authMiddleware(['admin']), async (req, res) => {
  try {
    const out = await Animal.findByIdAndDelete(req.params.id);
    if (!out) return res.status(404).json({ error: 'Not found' });
    cache.clear();
    res.json({ ok: true });
  } catch (e) {
    console.error(e);
    res.status(400).json({ error: 'Delete failed' });
  }
});

export default router;
