import express from 'express';
import { Animal } from '../models/animal.js';

const router = express.Router();

router.get('/candidates', async (req, res) => {
  try {
    const pipeline = [
      { $match: { species: 'dog', age: { $lt: 7 }, temperament: { $ne: 'aggressive' } } },
      { $group: { _id: '$breed', count: { $sum: 1 } } },
      { $sort: { count: -1 } },
      { $limit: 10 }
    ];
    const result = await Animal.aggregate(pipeline);
    res.json(result);
  } catch (e) {
    console.error(e);
    res.status(500).json({ error: 'Aggregation failed' });
  }
});

export default router;
