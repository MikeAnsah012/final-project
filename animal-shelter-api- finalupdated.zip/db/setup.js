import mongoose from 'mongoose';

const MONGO_URI = process.env.MONGO_URI || 'mongodb://localhost:27017/animalshelter';

const run = async () => {
  await mongoose.connect(MONGO_URI);
  const db = mongoose.connection.db;
  const coll = db.collection('animals');

  await db.command({
    collMod: 'animals',
    validator: {
      $jsonSchema: {
        bsonType: 'object',
        required: ['name','species','age','location'],
        properties: {
          name: { bsonType: 'string' },
          species: { enum: ['dog','cat'] },
          age: { bsonType: ['int','double'] },
          location: {
            bsonType: 'object',
            required: ['type','coordinates'],
            properties: {
              type: { enum: ['Point'] },
              coordinates: { bsonType: 'array', minItems: 2, maxItems: 2 }
            }
          }
        }
      }
    },
    validationLevel: 'moderate'
  }).catch(()=>{});

  await coll.createIndex({ breed: 1, age: 1 });
  await coll.createIndex({ notes: 'text', name: 'text', breed: 'text' });
  await coll.createIndex({ location: '2dsphere' });

  console.log('Validator and indexes ensured.');
  await mongoose.disconnect();
};

run().catch(err => { console.error(err); process.exit(1); });
