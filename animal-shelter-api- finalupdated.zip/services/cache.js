export class LRUCache {
  constructor(limit = 100) { this.limit = limit; this.map = new Map(); }
  get(key) { if (!this.map.has(key)) return; const v = this.map.get(key); this.map.delete(key); this.map.set(key,v); return v; }
  set(key, val) { if (this.map.has(key)) this.map.delete(key); this.map.set(key,val); if (this.map.size>this.limit){ const k=this.map.keys().next().value; this.map.delete(k);} }
  clear(){ this.map.clear(); }
}
