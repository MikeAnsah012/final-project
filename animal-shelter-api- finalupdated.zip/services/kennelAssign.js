export function assignKennels(animals, kennels) {
  const compat = (a,b) => !(a.temperament === 'aggressive' && b.temperament !== 'calm');
  const placed = [];
  const sorted = [...animals].sort((a,b) => b.score - a.score);
  for (const a of sorted) {
    let done = false;
    for (const k of kennels) {
      if ((k.animals?.length || 0) < k.capacity) {
        if (!k.animals || k.animals.every(x => compat(a,x))) {
          k.animals = k.animals || []; k.animals.push(a);
          placed.push({ dog:a.name, kennel:k.name });
          done = true; break;
        }
      }
    }
    if (!done) placed.push({ dog:a.name, kennel:null });
  }
  return placed;
}
