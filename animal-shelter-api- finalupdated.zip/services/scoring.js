export function adoptabilityScore(animal) {
  const ageScore = Math.max(0, 30 - (animal.age ?? 0)) / 30;
  const temperamentMap = { calm: 1.0, balanced: 0.8, active: 0.7, anxious: 0.4, aggressive: 0.2 };
  const tempScore = temperamentMap[animal.temperament] ?? 0.6;
  const trainingScore = Math.min(1, (animal.trainingHistory ?? 0) / 40);
  const healthPenalty = (animal.healthFlags ?? []).length ? 0.15 : 0.0;
  const weighted = 0.35*ageScore + 0.35*tempScore + 0.25*trainingScore - healthPenalty;
  return Math.max(0, Math.min(1, weighted)) * 100;
}
