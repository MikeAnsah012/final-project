import mongoose from 'mongoose';

const AnimalSchema = new mongoose.Schema({
  name: { type: String, required: true, trim: true },
  species: { type: String, default: 'dog', index: true },
  breed: { type: String, index: true },
  age: { type: Number, min: 0, index: true },
  temperament: { type: String, enum: ['calm','active','anxious','aggressive','balanced'], default: 'balanced' },
  notes: { type: String, default: '' },
  healthFlags: [{ type: String }],
  trainingHistory: { type: Number, default: 0 },
  location: {
    type: { type: String, enum: ['Point'], default: 'Point' },
    coordinates: { type: [Number], default: [0,0], index: '2dsphere' }
  },
  createdAt: { type: Date, default: Date.now },
  updatedAt: { type: Date, default: Date.now }
});

AnimalSchema.index({ breed: 1, age: 1 });
AnimalSchema.index({ notes: 'text', name: 'text', breed: 'text' });

AnimalSchema.pre('save', function(next) { this.updatedAt = new Date(); next(); });

export const Animal = mongoose.model('Animal', AnimalSchema);
