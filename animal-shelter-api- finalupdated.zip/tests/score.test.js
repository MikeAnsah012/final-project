import { test } from 'node:test';
import assert from 'node:assert/strict';
import { adoptabilityScore } from '../services/scoring.js';

test('adoptabilityScore basics', () => {
  const s1 = adoptabilityScore({ age: 2, temperament: 'calm', trainingHistory: 20, healthFlags: [] });
  const s2 = adoptabilityScore({ age: 12, temperament: 'aggressive', trainingHistory: 0, healthFlags: ['injury'] });
  assert.ok(s1 > s2);
});
