import { test } from 'node:test';
import assert from 'node:assert/strict';
import { LRUCache } from '../services/cache.js';

test('LRUCache evicts least-recently-used', () => {
  const c = new LRUCache(2);
  c.set('a',1); c.set('b',2);
  c.get('a');
  c.set('c',3); // evict b
  assert.equal(c.get('b'), undefined);
  assert.equal(c.get('a'),1);
  assert.equal(c.get('c'),3);
});
