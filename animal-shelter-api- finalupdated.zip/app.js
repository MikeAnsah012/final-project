import express from 'express';
import cors from 'cors';
import morgan from 'morgan';
import dotenv from 'dotenv';
import mongoose from 'mongoose';
import animalRoutes from './routes/animals.js';
import analyticsRoutes from './routes/analytics.js';
import { authMiddleware, issueToken } from './middleware/auth.js';

dotenv.config();
const app = express();
app.use(cors());
app.use(express.json());
app.use(morgan('dev'));

app.get('/health', (req, res) => res.json({ ok: true }));

app.post('/auth/token', (req, res) => {
  const { email = 'viewer@example.com', role = 'viewer' } = req.body || {};
  const token = issueToken({ email, role });
  res.json({ token, role, email });
});

app.use('/api/animals', animalRoutes);
app.use('/api/analytics', analyticsRoutes);

app.get('/api/admin/ping', authMiddleware(['admin']), (req, res) => {
  res.json({ message: `Hello ${req.user?.email}`, role: req.user?.role });
});

const PORT = process.env.PORT || 8080;
const MONGO_URI = process.env.MONGO_URI || 'mongodb://localhost:27017/animalshelter';
mongoose.connect(MONGO_URI).then(() => {
  console.log('MongoDB connected');
  app.listen(PORT, () => console.log(`API running on :${PORT}`));
}).catch(err => { console.error('Mongo connection error:', err); process.exit(1); });

export default app;
